package com.grocerylist.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="grocerylistdetails")
public class GroceryListModel {
	@Id
	private int id;
	private String name;
	private int quantity;
	private double costprice;
	private double sellingprice;
	private double totalinvestment;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getCostprice() {
		return costprice;
	}
	public void setCostprice(double costprice) {
		this.costprice = costprice;
	}
	public double getSellingprice() {
		return sellingprice;
	}
	public void setSellingprice(double sellingprice) {
		this.sellingprice = sellingprice;
	}
	public double getTotalinvestment() {
		return totalinvestment;
	}
	public void setTotalinvestment(double totalinvestment) {
		this.totalinvestment = totalinvestment;
	}
	public GroceryListModel(int id, String name, int quantity, double costprice, double sellingprice, double totalinvestment) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.costprice = costprice;
		this.sellingprice = sellingprice;
		this.totalinvestment = totalinvestment;
	}
	public GroceryListModel() {
		
	}

}
