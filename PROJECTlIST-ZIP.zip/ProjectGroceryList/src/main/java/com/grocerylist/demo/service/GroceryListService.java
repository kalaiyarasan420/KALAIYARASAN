package com.grocerylist.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.grocerylist.demo.model.GroceryListModel;
import com.grocerylist.demo.repository.GroceryListRepository;

public class GroceryListService {

	@Autowired
	GroceryListRepository groceryListRepository;
	
	public List<GroceryListModel> getGroceryDetails(){
		return groceryListRepository.findAll();
		
	}
	public GroceryListModel postGroceryDetails(GroceryListModel G) {
		return groceryListRepository.save(G);
	}
	public GroceryListModel updateGroceryDetails(GroceryListModel G) {
		return groceryListRepository.save(G);
	}
	public String deleteGroceryDetails(int id) {
		groceryListRepository.deleteById(id);
		return "Id : "+id+" is deteled";
	}
}
