package com.grocerylist.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.grocerylist.demo.model.GroceryListModel;
import com.grocerylist.demo.service.GroceryListService;

@RestController

public class GroceryListController {
       
	@Autowired
	GroceryListService groceryListService;
	
	@GetMapping("/get")
	public List<GroceryListModel> getGroceryDetails(){
		return groceryListService.getGroceryDetails();
	}
	@PostMapping("/post")
	public GroceryListModel postGroceryDetails(@RequestBody GroceryListModel G) {
		return groceryListService.postGroceryDetails(G);
	}	
	@PutMapping("/put/{id}")
	public GroceryListModel updateGroceryDetails(@RequestBody GroceryListModel G) {
		return groceryListService.updateGroceryDetails(G);
	}
	@DeleteMapping("/delete/{id}")
	public String deleteGroceryDetails(@PathVariable("id") int id) {
		return groceryListService.deleteGroceryDetails(id);
	}
}
