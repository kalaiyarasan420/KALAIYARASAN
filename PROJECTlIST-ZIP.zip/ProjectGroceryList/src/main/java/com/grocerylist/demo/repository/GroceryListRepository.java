package com.grocerylist.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerylist.demo.model.GroceryListModel;

public interface GroceryListRepository extends JpaRepository<GroceryListModel,Integer> {

}
